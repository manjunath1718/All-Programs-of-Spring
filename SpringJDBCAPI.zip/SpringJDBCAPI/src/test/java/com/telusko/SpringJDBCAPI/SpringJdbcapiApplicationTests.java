package com.telusko.SpringJDBCAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
