package com.telusko.SpringJDBCAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbcapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcapiApplication.class, args);
	}

}
