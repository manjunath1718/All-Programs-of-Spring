package com.telusko.SpringBoot01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
