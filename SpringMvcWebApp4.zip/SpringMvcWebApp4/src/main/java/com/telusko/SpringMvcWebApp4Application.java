package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcWebApp4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcWebApp4Application.class, args);
	}

}
